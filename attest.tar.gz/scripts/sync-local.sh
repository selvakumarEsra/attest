#!/usr/bin/env bash
#
# sync-local.sh — sync dist/ → .claude/ for self-hosting development
#
# This repo eats its own dog food: the commands and skill defined in
# dist/ are also used to develop this repo itself. .claude/ is the
# generated local copy that Claude Code picks up when you open this repo.
#
# Workflow:
#   1. Edit files under dist/ (the source of truth)
#   2. Run ./scripts/sync-local.sh
#   3. .claude/ is regenerated to match dist/
#   4. Commit dist/ AND .claude/ together
#
# CI checks that the two are in sync via scripts/verify-sync.sh.

set -euo pipefail

REPO_ROOT=$(cd "$(dirname "$0")/.." && pwd)
DIST="$REPO_ROOT/dist"
LOCAL="$REPO_ROOT/.claude"

if [[ ! -d "$DIST" ]]; then
    echo "Missing dist/ — run from a clone of attest" >&2
    exit 1
fi

echo "Syncing $DIST → $LOCAL"

# Wipe and regenerate .claude/commands and .claude/skills
rm -rf "$LOCAL/commands" "$LOCAL/skills"
mkdir -p "$LOCAL/commands" "$LOCAL/skills/claude-md-architect/references"

# Commands (excluding the auxiliary README and test-fixtures — those
# are bundle documentation, not slash commands)
for cmd in spec contract work check fix; do
    cp "$DIST/commands/${cmd}.md" "$LOCAL/commands/${cmd}.md"
done

# Skill
cp "$DIST/skill/claude-md-architect/SKILL.md" "$LOCAL/skills/claude-md-architect/SKILL.md"
for ref in template nested-template conversion-rules examples hierarchy-examples; do
    cp "$DIST/skill/claude-md-architect/references/${ref}.md" \
       "$LOCAL/skills/claude-md-architect/references/${ref}.md"
done

echo "Done. .claude/ is now in sync with dist/."
echo "Remember to commit both."
