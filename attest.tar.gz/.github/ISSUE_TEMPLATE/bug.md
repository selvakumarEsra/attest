---
name: Bug report
about: Something doesn't work as documented
title: '[bug] '
labels: bug
---

**What were you trying to do?**

(One or two sentences. Be concrete — which command, which spec, what scope.)

**What happened?**

(Actual behaviour — error message, wrong output, refused-to-run, etc.)

**What did you expect?**

(Documented behaviour, per the README or the command file.)

**Reproduction steps**

```
1. ...
2. ...
3. ...
```

**Environment**

- Claude Code version:
- OS:
- Repo type (backend-only / frontend-only / full-stack / library):

**Anything else?**
