---
name: Workflow gap
about: Something isn't covered by the current workflow and you've hit it on a real ticket
title: '[gap] '
labels: enhancement
---

**The scenario**

(Describe the real ticket or situation that exposed the gap. Not hypothetical — actual.)

**What you tried**

(Which commands you ran, in what order, and where the workflow fell short.)

**What you'd want the workflow to do**

(Specific. "Add a new command" is too vague; "extend /work to also do X" is good.)

**Why current commands don't cover this**

(Explain why the gap can't be closed by editing an existing command's prompt or template.)

**Suggested trigger**

(Every new piece in attest has a "when to add it" trigger. What's the trigger for this one? E.g. "Add this when you've shipped 3 bugs in a month that current /check would have caught.")

**Workaround you're using meanwhile**

(So others with the same gap know what to do until the workflow handles it.)
