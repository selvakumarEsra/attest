#!/usr/bin/env bash
#
# ledger.sh — bash helpers for the attest observability ledger
#
# Source this in any script:
#     source .attest/ledger/ledger.sh
#
# Then use:
#     attest_log session_start command=spec artifact_path=specs/foo.md
#     attest_log session_end session_id="$SID" outcome=completed
#     attest_session_id  # generates a UUID
#
# All helpers call attest_ledger.py under the hood. They never fail in a way
# that would break the calling command — ledger writes are best-effort. If
# the ledger is broken, attest commands still work; you just lose the trace.

# Resolve the path to attest_ledger.py
_attest_ledger_py() {
    # 1. Look in the calling repo's .attest/ledger/
    local repo
    repo="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
    if [[ -f "$repo/.attest/ledger/attest_ledger.py" ]]; then
        echo "$repo/.attest/ledger/attest_ledger.py"
        return 0
    fi
    # 2. Look next to this script (the installed location)
    local self_dir
    self_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    if [[ -f "$self_dir/attest_ledger.py" ]]; then
        echo "$self_dir/attest_ledger.py"
        return 0
    fi
    return 1
}

attest_log() {
    # attest_log <event_type> [key=value ...]
    # Best-effort. Stderr captured; never propagates failure.
    local event_type="$1"; shift
    local script
    if ! script=$(_attest_ledger_py); then
        return 0  # ledger not installed, silently skip
    fi
    python3 "$script" log "$event_type" "$@" --quiet 2>/dev/null || true
}

attest_session_id() {
    # Print a fresh UUID for use as session_id
    python3 -c "import uuid; print(uuid.uuid4())"
}

attest_summary() {
    local script
    script=$(_attest_ledger_py) || { echo "ledger not installed" >&2; return 1; }
    python3 "$script" summary "$@"
}

attest_rebuild_index() {
    local script
    script=$(_attest_ledger_py) || { echo "ledger not installed" >&2; return 1; }
    python3 "$script" rebuild-index "$@"
}
