---
description: Execute work against a spec file OR a fix file. For full-stack specs/fixes, takes a --scope argument (backend or frontend) and stays within that scope. Runs drift detection on entry and exit, and Pact provider tests on backend completion if artifacts exist.
argument-hint: <path-to-spec-or-fix-file> [--scope backend|frontend]
---

# /work — Execute Against a Spec or Fix

You are executing work defined by either a spec file (`specs/*.md`) or a fix file (`fixes/*.md`). Both are contracts. You do not invent work that isn't in the input artifact; you do not skip work that is. For full-stack work, you operate within ONE scope per invocation.

## Inputs

The user has invoked this command with: $ARGUMENTS

Parse:
- First positional argument: path to a spec file or fix file
- Optional `--scope backend` or `--scope frontend`

If the path is missing, ask which artifact to work on.

## Determine artifact type

Look at the path:
- Begins with `specs/` → **spec mode**. Standard behaviour.
- Begins with `fixes/` → **fix mode**. Variations described in each section below.

If the path is somewhere else, ask the user to confirm.

## Pre-flight

### Step 1: Read context
- Read `CLAUDE.md` at the repo root. Every invariant applies. If absent, warn and stop.
- Read the input file (spec or fix) completely.
- **Fix mode**: also read the spec referenced by the fix's `Against spec:` field. The spec defines the original contract; the fix defines the deviation and resolution.

### Step 2: Status and scope checks

**Spec mode:**
- Verify spec status is `draft`, `in-progress`, or `contract-locked` (not `done`, `signed-off`, or `ready-for-review`).
- Verify all "Open questions" are closed.
- Determine working scope:
  - `backend-only` spec → scope is `backend`
  - `frontend-only` spec → scope is `frontend`
  - `full-stack` spec → `--scope` is **required**; if missing, ask

**Fix mode:**
- Verify fix status is `draft`, `in-progress`, or `emergency` (not `signed-off` or `done`).
- Verify "Root cause" section is not "Under investigation" — if it is, stop and tell the user to complete the analysis first.
- Verify "Open questions" are closed.
- Verify the regression test acceptance criterion is present (do NOT verify the test exists yet — that's part of execution; just verify the criterion is in the fix).
- Determine working scope from the *referenced spec's* scope:
  - Original spec was `backend-only` → fix scope is `backend`
  - Original spec was `frontend-only` → fix scope is `frontend`
  - Original spec was `full-stack` → `--scope` is **required**
- Fix mode rule: if the fix is Case 2 or Case 4 AND the new superseding spec exists, verify it has been through `/contract` (status `contract-locked`). If not, stop and tell the user to run `/contract specs/<new-spec>.md` first.

### Step 3: Run /check (drift detection)
Invoke the `/check` command internally:
- Pass the spec path and the working scope
- Use fast mode (no `--deep`)
- If the spec status is `in-progress` (resumed work), use `--deep`

Read the resulting drift report and act on it:
- **Check 1 fails** (contract hash mismatch — see `/contract` for how hashes are computed over the normalised Contract surface section) → STOP. Tell user to run `/contract`.
- **Check 2 fails** (ticked criteria with no traceable code) → STOP. Ask user whether to untick the criteria or restore the code.
- **Check 3 fails** (changed files with no spec coverage) → WARN. Include in the plan; ask user to confirm these changes are intentional.
- **Check 4 flags** (suspected divergence, on resume) → WARN. Include in the plan; ask user to adjudicate.

### Step 4: Contract artifact check (full-stack only)
- If spec has Contract surface section but no `_generated/` artifacts → STOP. Tell user to run `/contract`.
- Confirm the spec's `Contract hash` matches the artifacts (this is redundant with Check 1 but is a defence-in-depth).

If any pre-flight step fails, stop. Do not proceed to planning.

## Plan first

After pre-flight passes:

1. Update artifact status to `in-progress` (spec file in spec mode, fix file in fix mode).

2. Identify scope's surface area:
   - **Backend scope** — read backend acceptance criteria, backend "Files likely to change", backend tests, and the contract artifacts you will *implement* (server-side stubs, validation rules). You are the contract producer.
   - **Frontend scope** — read frontend acceptance criteria, frontend "Files likely to change", frontend tests, and the contract artifacts you will *consume* (TS types, API client stubs). You are the contract consumer.

3. **Fix mode addition:** include the fix's "Resolution" section in your plan. The resolution describes specifically what changes. If the resolution disagrees with the referenced spec (or its superseding version), the spec wins — the resolution is a plan, the spec is the contract.

4. Produce a plan covering:
   - Order in which you'll address THIS scope's acceptance criteria
   - Files in THIS scope you'll create or modify
   - Tests in THIS scope you'll write or update (in fix mode, include the regression test explicitly)
   - Generated artifacts you'll import (read-only)
   - Invariants from `CLAUDE.md` that constrain the approach
   - Any warnings from the drift check that affect the plan

5. Present the plan and **wait for approval** before executing.

## Execute

After approval:

1. Work through THIS scope's acceptance criteria in order.
2. Tick checkboxes as criteria complete (scope-prefixed for clarity).
3. **Import generated types and schemas — do not redefine them.** Re-declaring is how drift starts.
4. **Do not write code in the other scope.** If you find yourself outside scope, stop.
5. Add traceability comments per `CLAUDE.md` convention:
   - **Spec mode:** `§ref:specs/<filename>`
   - **Fix mode:** `§ref:fixes/<filename>` (the fix carries the bug context, which is what the audit trail needs to see)
   - If the fix Case is 2 or 4 and a new superseding spec exists, ALSO add `§ref:specs/<new-spec>` on lines that implement the new contract
6. Run scope-relevant verification commands periodically (not the full suite — that's post-flight).
7. **Fix mode addition:** as part of execution, write the regression test described in the fix's "Regression test required" section. Verify it fails against the buggy behaviour first, then passes after the fix. If you can't reproduce the bug to write a failing test, stop and ask the user.
8. Stop and ask if you hit something the artifact doesn't cover. Do not invent.

### Mid-flight boundary violations

If you discover the contract is wrong (missing field, wrong type, missing endpoint):

1. **Stop.** Do not work around it. Do not extend the contract locally.
2. Tell the user exactly what's wrong.
3. Suggest:
   - **Spec mode:** *"Edit the spec's Contract surface section, then re-run `/contract`, then re-invoke `/work`."*
   - **Fix mode:** *"This looks like Case 2 (spec was wrong) rather than what the fix classified. Consider stopping this `/work`, re-running `/fix` to upgrade to Case 2, and creating a superseding spec."*
4. Wait.

## Post-flight

When all acceptance criteria in THIS scope are ticked:

### Step 1: Full verification suite
Run the verification commands from `CLAUDE.md`'s "How to verify work is done" section, filtered to this scope.

### Step 2: Pact verification (backend scope, if artifacts exist)
If `--scope backend` AND `_generated/pact/` contains files:
- Locate the Pact verification command (check `CLAUDE.md`, then check `pom.xml`/`build.gradle`/`package.json` for Pact-related tasks).
- Run it. The Pact stubs in `_generated/pact/` define what the frontend expects; this verification proves the backend delivers it.
- If Pact verification fails, the backend has produced something that diverges from the contract. STOP. Surface the failure. The user must either fix the backend to match the contract OR edit the spec, re-run `/contract`, and re-verify.

### Step 3: Run /check again (post-completion drift detection)
Invoke `/check` with the working scope. This catches:
- New files created during work that don't carry `§ref` traceability
- Contract artifacts that changed during the session (someone re-ran `/contract` in parallel)
- Code-implies-spec divergence (cheap version, only files we touched)

If anything flags, surface it before marking ready-for-review.

### Step 4: Update artifact status

**Spec mode:**
- `backend-only` or `frontend-only` spec → status to `ready-for-review`
- `full-stack` spec with only this scope complete → add `Backend complete: YYYY-MM-DD` (or `Frontend complete: ...`) to metadata; status stays `in-progress`
- `full-stack` spec with the other scope's marker already present → status to `ready-for-review`

**Fix mode:**
- Single-scope fix → status to `ready-for-review`
- Full-stack fix with only this scope complete → add scope-complete marker; status stays `in-progress`
- Full-stack fix with both scopes complete → status to `ready-for-review`
- If the fix is Case 2 or 4 with a superseding spec, ALSO advance that spec through the normal status progression (treat the spec as if /work had been run against it directly — `contract-locked` → `in-progress` → `ready-for-review` once execution touches files under its scope).

### Step 5: Append execution notes

**Spec mode:** add `## Execution notes (backend)` or `## Execution notes (frontend)` to the spec.

**Fix mode:** add `## Execution notes (backend)` / `## Execution notes (frontend)` to the **fix file**. The fix file is the canonical execution record for the bug — not the spec. If Case 2 or 4 advanced a superseding spec, also add a brief execution notes section to that spec referencing the fix.

Either way, the execution notes include:
- Final list of files changed in this scope
- Deviations from plan and why
- Follow-ups not covered
- Drift findings from post-flight `/check`, if any
- **Fix mode addition:** confirmation that the regression test was written and that it fails against the pre-fix code (described, not necessarily re-run)

### Step 6: Tell the user
- If `ready-for-review` → suggest review and commit
- If still `in-progress` → tell the user the other scope is outstanding and what to run
- **Fix mode addition:** if the fix is `--hot` or status was `emergency`, surface any deferred follow-ups loudly (e.g. "regression test was added inline — confirm coverage in CR" or "monitoring alert not yet configured").

## What not to do

- Do not commit code. The human commits, after review. The pre-commit hook enforces spec/fix-linkage.
- Do not modify the spec's acceptance criteria or contract surface mid-flight. If wrong, stop and ask.
- Do not modify the fix's classification mid-flight. If you realise the case is different, stop and re-run `/fix`.
- Do not modify files in `_generated/`. Read-only inputs from `/contract`.
- Do not work across scopes in one invocation.
- Do not skip drift checks because "the previous session was mine". Re-running on a stale spec/fix is the most common drift cause.
- Do not skip Pact verification because "tests pass locally". The Pact stub is what the frontend expects; deviating from it is drift.
- Do not skip the regression test in fix mode. The test can be inline rather than perfect, but it must exist.
- Do not work on an artifact whose status is `signed-off` or `done`. Open a new fix or spec for follow-ups.
- Do not re-declare types from `_generated/`. Import them.
